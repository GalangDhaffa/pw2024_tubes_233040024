<section id="footer">
    <footer>
      <div class="container-footer">
        <div class="socialicons d-flex">
          <a href="https://www.instagram.com/secreto.custom/"><i><img width="60" height="60" src="img/logo/Instagram.png" alt="logo" /></i></a>
          <a href="https://discord.gg/aCNg6GCx"><i><img width="60" height="60" src="img/logo/Discord.png" alt="logo" /></i></a>
          <a href="https://prestigeworld.id/"><i><img width="60" height="60" src="img/logo/Prestige.png" alt="logo" /></i></a>
          <a href="https://galangdhaffa.github.io/itw2023_project2_233040024/"><i><img width="60" height="60" src="img/logo/logo4.png" alt="logo" /></i></a>
        </div>
        <div class="footernav">
          <ul>
            <li><a href="#home">Home</a></li>

            <li><a href="#about">About</a></li>

            <li><a href="#gallery">Gallery</a></li>

            <li><a href="#produk">produk</a></li>

            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>
      </div>
      <div class="footer-bottom">
        <p>
          CopyRight &copy;2023; Designed by
          <span class="Designer">Dhaffa Galang Fahriza</span>
        </p>
      </div>
    </footer>
  </section>