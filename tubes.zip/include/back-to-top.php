<button id="back-to-top" onclick="scrollToTop()"><span class="material-symbols-outlined">
      <svg xmlns="http://www.w3.org/2000/svg" height="48px" viewBox="0 -960 960 960" width="48px" fill="#e8eaed">
        <path d="M435-139v-508L202-415l-63-65 342-342 341 341-64 66-232-232v508h-91Z" />
      </svg>
    </span>
  </button>
  